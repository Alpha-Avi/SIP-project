import React from 'react';
import Navbar from './Navbar';
import TranslatorPanel from './TranslatorPanel';
import ExampleTranslations from './ExampleTranslations';
import Footer from './Footer';
import { motion } from 'framer-motion';
import { useTheme } from '../contexts/ThemeContext';

const TranslatorApp: React.FC = () => {
  const { theme } = useTheme();
  
  return (
    <div className={`min-h-screen flex flex-col transition-colors duration-300 ${
      theme === 'dark' ? 'bg-gray-900 text-white' : 'bg-gray-50 text-gray-900'
    }`}>
      <Navbar />
      
      <main className="flex-grow container mx-auto px-4 py-8 md:py-12">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="text-center mb-8"
        >
          <h1 className="text-3xl md:text-4xl font-bold bg-gradient-to-r from-primary-600 to-secondary-500 text-transparent bg-clip-text">
            Translate Anything, Anywhere
          </h1>
          <p className={`mt-4 max-w-2xl mx-auto ${theme === 'dark' ? 'text-gray-300' : 'text-gray-600'}`}>
            Break language barriers with our AI-powered translation. Communicate effortlessly across languages with perfect accuracy.
          </p>
        </motion.div>
        
        <TranslatorPanel />
        
        <ExampleTranslations />
      </main>
      
      <Footer />
    </div>
  );
};

export default TranslatorApp;