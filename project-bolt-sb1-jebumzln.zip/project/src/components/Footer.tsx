import React from 'react';
import { motion } from 'framer-motion';
import { Globe, Heart } from 'lucide-react';
import { useTheme } from '../contexts/ThemeContext';

const Footer: React.FC = () => {
  const { theme } = useTheme();
  
  return (
    <footer className={`py-8 border-t ${
      theme === 'dark' ? 'bg-gray-900 border-gray-800 text-gray-300' : 'bg-white border-gray-200 text-gray-600'
    }`}>
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row justify-between items-center">
          <div className="flex items-center mb-4 md:mb-0">
            <motion.div 
              whileHover={{ rotate: 360 }}
              transition={{ duration: 0.5 }}
              className="mr-2"
            >
              <Globe className="w-5 h-5 text-primary-500" />
            </motion.div>
            <span className="font-medium">Lingua Translator</span>
          </div>
          
          <div className="flex items-center text-sm">
            <span>Made with</span>
            <motion.div 
              whileHover={{ scale: 1.2 }}
              className="mx-1 text-error-500"
            >
              <Heart size={14} fill="currentColor" />
            </motion.div>
            <span>for a world without language barriers</span>
          </div>
          
          <div className="mt-4 md:mt-0 text-sm">
            <span>&copy; 2025 Lingua Translator</span>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;