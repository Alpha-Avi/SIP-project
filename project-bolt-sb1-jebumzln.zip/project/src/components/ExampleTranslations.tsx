import React from 'react';
import { motion } from 'framer-motion';
import { useTheme } from '../contexts/ThemeContext';

const ExampleTranslations: React.FC = () => {
  const { theme } = useTheme();
  
  const examples = [
    {
      phrase: "Hello, how are you?",
      translations: [
        { language: "Spanish", text: "Hola, ¿cómo estás?" },
        { language: "French", text: "Bonjour, comment ça va?" },
        { language: "Japanese", text: "こんにちは、お元気ですか？" }
      ]
    },
    {
      phrase: "Thank you very much",
      translations: [
        { language: "German", text: "Vielen Dank" },
        { language: "Italian", text: "Grazie mille" },
        { language: "Chinese", text: "非常感谢" }
      ]
    },
    {
      phrase: "Where is the restaurant?",
      translations: [
        { language: "Arabic", text: "أين المطعم؟" },
        { language: "Russian", text: "Где ресторан?" },
        { language: "Hindi", text: "रेस्तरां कहां है?" }
      ]
    }
  ];
  
  const container = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2
      }
    }
  };
  
  const item = {
    hidden: { opacity: 0, y: 20 },
    show: { opacity: 1, y: 0 }
  };

  const cardClasses = `rounded-xl p-5 ${
    theme === 'dark' ? 'bg-gray-800' : 'bg-white'
  } shadow-soft h-full`;

  return (
    <section className="mt-16 mb-12">
      <div className="text-center mb-8">
        <h2 className="text-2xl font-bold">Popular Translations</h2>
        <p className={`mt-2 ${theme === 'dark' ? 'text-gray-300' : 'text-gray-600'}`}>
          Quick examples to help you get started
        </p>
      </div>
      
      <motion.div 
        variants={container}
        initial="hidden"
        whileInView="show"
        viewport={{ once: true, margin: "-100px" }}
        className="grid grid-cols-1 md:grid-cols-3 gap-6"
      >
        {examples.map((example, index) => (
          <motion.div key={index} variants={item}>
            <div className={cardClasses}>
              <h3 className={`text-lg font-medium ${
                theme === 'dark' ? 'text-white' : 'text-gray-900'
              }`}>
                {example.phrase}
              </h3>
              
              <div className="mt-4 space-y-3">
                {example.translations.map((translation, tIndex) => (
                  <div key={tIndex} className={`p-3 rounded-lg ${
                    theme === 'dark' ? 'bg-gray-700' : 'bg-gray-50'
                  }`}>
                    <p className={`text-xs font-medium ${
                      theme === 'dark' ? 'text-gray-400' : 'text-gray-500'
                    }`}>
                      {translation.language}
                    </p>
                    <p className={`mt-1 ${
                      theme === 'dark' ? 'text-gray-200' : 'text-gray-800'
                    }`}>
                      {translation.text}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          </motion.div>
        ))}
      </motion.div>
    </section>
  );
};

export default ExampleTranslations;