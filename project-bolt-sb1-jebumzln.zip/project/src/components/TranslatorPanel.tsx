import React, { useState } from 'react';
import { motion } from 'framer-motion';
import LanguageSelector from './LanguageSelector';
import TranslationInput from './TranslationInput';
import TranslationOutput from './TranslationOutput';
import { ArrowUpDown, ArrowRight } from 'lucide-react';
import { useTheme } from '../contexts/ThemeContext';
import { translateText } from '../services/translationService';
import { Language } from '../types/language';
import { languages } from '../data/languages';

const TranslatorPanel: React.FC = () => {
  const { theme } = useTheme();
  const [sourceLanguage, setSourceLanguage] = useState<Language>(languages[0]); // English
  const [targetLanguage, setTargetLanguage] = useState<Language>(languages[1]); // Spanish
  const [inputText, setInputText] = useState<string>('');
  const [translatedText, setTranslatedText] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [isDetecting, setIsDetecting] = useState<boolean>(false);

  const handleTranslate = async () => {
    if (!inputText.trim()) return;
    
    setIsLoading(true);
    
    try {
      const result = await translateText({
        text: inputText,
        sourceLanguage: sourceLanguage.code,
        targetLanguage: targetLanguage.code,
      });
      
      setTranslatedText(result);
    } catch (error) {
      console.error('Translation error:', error);
      setTranslatedText('Sorry, there was an error with translation.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleSwapLanguages = () => {
    setSourceLanguage(targetLanguage);
    setTargetLanguage(sourceLanguage);
    setInputText(translatedText);
    setTranslatedText(inputText);
  };

  const handleDetectLanguage = async () => {
    if (!inputText.trim()) return;
    
    setIsDetecting(true);
    
    // Simulate language detection (in a real app, we would call an API)
    setTimeout(() => {
      // For demo, let's pretend we detected Spanish if the source isn't already Spanish
      const detectedLanguage = languages.find(lang => 
        lang.name !== sourceLanguage.name && lang.code === 'es'
      ) || languages[0];
      
      setSourceLanguage(detectedLanguage);
      setIsDetecting(false);
    }, 1000);
  };

  const cardClasses = `rounded-2xl shadow-soft ${
    theme === 'dark' ? 'bg-gray-800' : 'bg-white'
  }`;

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.2 }}
      className="max-w-4xl mx-auto mb-12"
    >
      <div className={cardClasses}>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 p-4">
          <div className="flex flex-col h-full">
            <div className="flex items-center justify-between mb-2">
              <LanguageSelector 
                selectedLanguage={sourceLanguage}
                onLanguageChange={setSourceLanguage}
                onDetectLanguage={handleDetectLanguage}
                isDetecting={isDetecting}
                includeDetect={true}
              />
            </div>
            
            <TranslationInput 
              value={inputText}
              onChange={setInputText}
              placeholder="Enter text to translate"
              onTranslate={handleTranslate}
            />
          </div>
          
          <div className="relative flex flex-col h-full">
            <div className="absolute left-0 top-1/2 transform -translate-y-1/2 -translate-x-1/2 md:flex hidden">
              <motion.button
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.9 }}
                onClick={handleSwapLanguages}
                className={`rounded-full p-2 ${
                  theme === 'dark' ? 'bg-gray-700 text-white' : 'bg-gray-100 text-gray-800'
                }`}
                aria-label="Swap languages"
              >
                <ArrowUpDown size={16} />
              </motion.button>
            </div>
            
            <div className="flex items-center justify-between mb-2">
              <LanguageSelector 
                selectedLanguage={targetLanguage}
                onLanguageChange={setTargetLanguage}
                includeDetect={false}
              />
            </div>
            
            <TranslationOutput 
              text={translatedText}
              isLoading={isLoading}
              sourceLanguage={sourceLanguage}
              targetLanguage={targetLanguage}
            />
          </div>
          
          <div className="md:hidden flex justify-center my-2">
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={handleSwapLanguages}
              className={`flex items-center rounded-full px-3 py-2 ${
                theme === 'dark' ? 'bg-gray-700 text-white' : 'bg-gray-100 text-gray-800'
              }`}
              aria-label="Swap languages"
            >
              <ArrowUpDown size={16} className="mr-2" />
              <span>Swap Languages</span>
            </motion.button>
          </div>
        </div>
        
        <div className={`flex justify-center p-4 ${
          theme === 'dark' ? 'border-t border-gray-700' : 'border-t border-gray-100'
        }`}>
          <motion.button
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={handleTranslate}
            disabled={!inputText.trim() || isLoading}
            className={`flex items-center justify-center px-6 py-3 rounded-lg font-medium transition-colors 
              ${inputText.trim() && !isLoading 
                ? 'bg-gradient-to-r from-primary-600 to-secondary-600 text-white hover:from-primary-700 hover:to-secondary-700' 
                : 'bg-gray-300 text-gray-500 cursor-not-allowed'
              }`}
          >
            <span>Translate</span>
            <ArrowRight size={18} className="ml-2" />
          </motion.button>
        </div>
      </div>
    </motion.div>
  );
};

export default TranslatorPanel;