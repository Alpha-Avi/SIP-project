import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Mic, X } from 'lucide-react';
import { useTheme } from '../contexts/ThemeContext';

interface TranslationInputProps {
  value: string;
  onChange: (value: string) => void;
  placeholder: string;
  onTranslate: () => void;
}

const TranslationInput: React.FC<TranslationInputProps> = ({
  value,
  onChange,
  placeholder,
  onTranslate
}) => {
  const { theme } = useTheme();
  const [isListening, setIsListening] = useState(false);
  
  const handleVoiceInput = () => {
    // Check if the browser supports speech recognition
    if ('SpeechRecognition' in window || 'webkitSpeechRecognition' in window) {
      const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
      const recognition = new SpeechRecognition();
      
      recognition.continuous = false;
      recognition.interimResults = false;
      
      recognition.onstart = () => {
        setIsListening(true);
      };
      
      recognition.onresult = (event) => {
        const transcript = event.results[0][0].transcript;
        onChange(transcript);
      };
      
      recognition.onerror = (event) => {
        console.error('Speech recognition error', event.error);
        setIsListening(false);
      };
      
      recognition.onend = () => {
        setIsListening(false);
      };
      
      recognition.start();
    } else {
      alert('Your browser does not support speech recognition.');
    }
  };
  
  const handleKeyDown = (e: React.KeyboardEvent) => {
    // Submit on Ctrl+Enter or Cmd+Enter
    if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
      onTranslate();
    }
  };
  
  const handleClearText = () => {
    onChange('');
  };

  return (
    <div className="relative flex-grow">
      <textarea
        value={value}
        onChange={(e) => onChange(e.target.value)}
        onKeyDown={handleKeyDown}
        placeholder={placeholder}
        className={`w-full h-40 p-4 rounded-lg resize-none focus:outline-none focus:ring-2 focus:ring-primary-400 ${
          theme === 'dark'
            ? 'bg-gray-700 text-white placeholder:text-gray-400'
            : 'bg-gray-50 text-gray-900 placeholder:text-gray-500'
        }`}
      />
      
      <div className="absolute bottom-3 right-3 flex space-x-2">
        {value && (
          <motion.button
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
            onClick={handleClearText}
            className={`p-2 rounded-full ${
              theme === 'dark' ? 'bg-gray-600 text-gray-300' : 'bg-gray-200 text-gray-600'
            }`}
            aria-label="Clear text"
          >
            <X size={16} />
          </motion.button>
        )}
        
        <motion.button
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.9 }}
          onClick={handleVoiceInput}
          className={`p-2 rounded-full ${
            isListening
              ? 'bg-primary-600 text-white animate-pulse'
              : theme === 'dark'
                ? 'bg-gray-600 text-gray-300'
                : 'bg-gray-200 text-gray-600'
          }`}
          aria-label="Voice input"
        >
          <Mic size={16} />
        </motion.button>
      </div>
      
      {isListening && (
        <div className="absolute inset-0 flex items-center justify-center bg-black/50 rounded-lg">
          <div className="text-center p-4 rounded-lg bg-white text-gray-900 shadow-soft-lg">
            <p className="mb-2 font-medium">Listening...</p>
            <div className="flex justify-center space-x-1">
              {[...Array(4)].map((_, i) => (
                <motion.div
                  key={i}
                  className="w-2 h-2 bg-primary-600 rounded-full"
                  animate={{
                    height: ['8px', '16px', '8px'],
                  }}
                  transition={{
                    duration: 1,
                    repeat: Infinity,
                    delay: i * 0.1,
                  }}
                />
              ))}
            </div>
            <p className="mt-2 text-xs text-gray-500">Speak clearly into your microphone</p>
          </div>
        </div>
      )}
    </div>
  );
};

export default TranslationInput;