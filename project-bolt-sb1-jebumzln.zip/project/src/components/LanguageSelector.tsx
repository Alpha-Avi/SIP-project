import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronDown, Search, RotateCw } from 'lucide-react';
import ReactCountryFlag from 'react-country-flag';
import { useTheme } from '../contexts/ThemeContext';
import { Language } from '../types/language';
import { languages } from '../data/languages';

interface LanguageSelectorProps {
  selectedLanguage: Language;
  onLanguageChange: (language: Language) => void;
  onDetectLanguage?: () => void;
  isDetecting?: boolean;
  includeDetect?: boolean;
}

const LanguageSelector: React.FC<LanguageSelectorProps> = ({
  selectedLanguage,
  onLanguageChange,
  onDetectLanguage,
  isDetecting = false,
  includeDetect = false
}) => {
  const { theme } = useTheme();
  const [isOpen, setIsOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const dropdownRef = useRef<HTMLDivElement>(null);
  
  // Filter languages based on search query
  const filteredLanguages = languages.filter(lang => 
    lang.name.toLowerCase().includes(searchQuery.toLowerCase())
  );
  
  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };
    
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  return (
    <div className="relative" ref={dropdownRef}>
      <button
        onClick={() => setIsOpen(!isOpen)}
        className={`flex items-center space-x-2 px-3 py-2 rounded-lg ${
          theme === 'dark' 
            ? 'hover:bg-gray-700 text-white' 
            : 'hover:bg-gray-100 text-gray-800'
        }`}
      >
        <ReactCountryFlag 
          countryCode={selectedLanguage.countryCode} 
          svg
          className="rounded-sm"
          style={{
            width: '1.2em',
            height: '1.2em'
          }}
        />
        <span className="font-medium">{selectedLanguage.name}</span>
        <ChevronDown size={16} className={`transition-transform ${isOpen ? 'rotate-180' : ''}`} />
      </button>

      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.2 }}
            className={`absolute z-20 mt-2 left-0 w-64 max-h-96 overflow-y-auto rounded-lg shadow-soft-lg ${
              theme === 'dark' ? 'bg-gray-800 border border-gray-700' : 'bg-white border border-gray-200'
            }`}
          >
            <div className={`sticky top-0 z-10 p-2 ${
              theme === 'dark' ? 'bg-gray-800' : 'bg-white'
            }`}>
              <div className={`flex items-center px-3 py-2 rounded-md ${
                theme === 'dark' ? 'bg-gray-700' : 'bg-gray-100'
              }`}>
                <Search size={16} className={theme === 'dark' ? 'text-gray-400' : 'text-gray-500'} />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search languages..."
                  className={`w-full bg-transparent border-none outline-none px-2 ${
                    theme === 'dark' ? 'text-white placeholder:text-gray-400' : 'text-gray-900 placeholder:text-gray-500'
                  }`}
                />
              </div>
            </div>
            
            <div className="p-1">
              {includeDetect && (
                <button
                  onClick={() => {
                    if (onDetectLanguage) onDetectLanguage();
                    setIsOpen(false);
                  }}
                  className={`flex items-center w-full px-3 py-2 rounded-md ${
                    theme === 'dark' 
                      ? 'hover:bg-gray-700 text-blue-400' 
                      : 'hover:bg-gray-100 text-blue-600'
                  }`}
                  disabled={isDetecting}
                >
                  {isDetecting ? (
                    <RotateCw size={16} className="mr-2 animate-spin" />
                  ) : (
                    <Search size={16} className="mr-2" />
                  )}
                  <span>Detect language</span>
                </button>
              )}
              
              {filteredLanguages.length > 0 ? (
                filteredLanguages.map(language => (
                  <button
                    key={language.code}
                    onClick={() => {
                      onLanguageChange(language);
                      setIsOpen(false);
                      setSearchQuery('');
                    }}
                    className={`flex items-center w-full px-3 py-2 rounded-md ${
                      selectedLanguage.code === language.code
                        ? theme === 'dark' 
                          ? 'bg-gray-700 text-primary-400' 
                          : 'bg-gray-100 text-primary-600'
                        : theme === 'dark' 
                          ? 'hover:bg-gray-700 text-white' 
                          : 'hover:bg-gray-100 text-gray-800'
                    }`}
                  >
                    <ReactCountryFlag 
                      countryCode={language.countryCode} 
                      svg
                      className="mr-2 rounded-sm"
                      style={{
                        width: '1.2em',
                        height: '1.2em'
                      }}
                    />
                    <span>{language.name}</span>
                  </button>
                ))
              ) : (
                <div className={`px-3 py-4 text-center ${
                  theme === 'dark' ? 'text-gray-400' : 'text-gray-500'
                }`}>
                  No languages found
                </div>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default LanguageSelector;