import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Copy, Volume2, Share2, Check } from 'lucide-react';
import { useTheme } from '../contexts/ThemeContext';
import { Language } from '../types/language';

interface TranslationOutputProps {
  text: string;
  isLoading: boolean;
  sourceLanguage: Language;
  targetLanguage: Language;
}

const TranslationOutput: React.FC<TranslationOutputProps> = ({
  text,
  isLoading,
  sourceLanguage,
  targetLanguage
}) => {
  const { theme } = useTheme();
  const [isCopied, setIsCopied] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);
  
  const handleCopyText = () => {
    if (!text) return;
    
    navigator.clipboard.writeText(text).then(() => {
      setIsCopied(true);
      setTimeout(() => setIsCopied(false), 2000);
    });
  };
  
  const handleTextToSpeech = () => {
    if (!text || isPlaying) return;
    
    const speech = new SpeechSynthesisUtterance(text);
    
    // Try to find a voice that matches the target language
    const voices = window.speechSynthesis.getVoices();
    const matchingVoice = voices.find(voice => 
      voice.lang.startsWith(targetLanguage.code) || 
      voice.lang.startsWith(targetLanguage.code.split('-')[0])
    );
    
    if (matchingVoice) {
      speech.voice = matchingVoice;
    }
    
    speech.lang = targetLanguage.code;
    speech.onstart = () => setIsPlaying(true);
    speech.onend = () => setIsPlaying(false);
    speech.onerror = () => setIsPlaying(false);
    
    window.speechSynthesis.speak(speech);
  };
  
  const handleShare = async () => {
    if (!text) return;
    
    if (navigator.share) {
      try {
        await navigator.share({
          title: `Translation from ${sourceLanguage.name} to ${targetLanguage.name}`,
          text: text,
        });
      } catch (error) {
        console.error('Error sharing:', error);
      }
    } else {
      alert('Web Share API is not supported in your browser.');
    }
  };

  return (
    <div className="relative flex-grow">
      {isLoading ? (
        <div className={`h-40 p-4 rounded-lg flex items-center justify-center ${
          theme === 'dark' ? 'bg-gray-700' : 'bg-gray-50'
        }`}>
          <div className="flex flex-col items-center">
            <div className="flex space-x-2 mb-3">
              {[...Array(3)].map((_, i) => (
                <motion.div
                  key={i}
                  className="w-2 h-2 bg-primary-500 rounded-full"
                  animate={{
                    y: ['0%', '-50%', '0%'],
                    opacity: [1, 0.5, 1],
                  }}
                  transition={{
                    duration: 1,
                    repeat: Infinity,
                    delay: i * 0.2,
                  }}
                />
              ))}
            </div>
            <p className={theme === 'dark' ? 'text-gray-300' : 'text-gray-600'}>
              Translating...
            </p>
          </div>
        </div>
      ) : (
        <div className={`h-40 p-4 rounded-lg overflow-y-auto ${
          theme === 'dark'
            ? 'bg-gray-700 text-white'
            : 'bg-gray-50 text-gray-900'
        }`}>
          {text ? (
            <p className="whitespace-pre-wrap">{text}</p>
          ) : (
            <p className={`text-center h-full flex items-center justify-center ${
              theme === 'dark' ? 'text-gray-400' : 'text-gray-500'
            }`}>
              Translation will appear here
            </p>
          )}
        </div>
      )}
      
      {text && !isLoading && (
        <div className="absolute bottom-3 right-3 flex space-x-2">
          <motion.button
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
            onClick={handleTextToSpeech}
            disabled={isPlaying}
            className={`p-2 rounded-full ${
              isPlaying
                ? 'bg-primary-600 text-white animate-pulse'
                : theme === 'dark'
                  ? 'bg-gray-600 text-gray-300'
                  : 'bg-gray-200 text-gray-600'
            }`}
            aria-label="Text to speech"
          >
            <Volume2 size={16} />
          </motion.button>
          
          <motion.button
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
            onClick={handleCopyText}
            className={`p-2 rounded-full ${
              isCopied
                ? 'bg-success-600 text-white'
                : theme === 'dark'
                  ? 'bg-gray-600 text-gray-300'
                  : 'bg-gray-200 text-gray-600'
            }`}
            aria-label="Copy to clipboard"
          >
            {isCopied ? <Check size={16} /> : <Copy size={16} />}
          </motion.button>
          
          <motion.button
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
            onClick={handleShare}
            className={`p-2 rounded-full ${
              theme === 'dark' ? 'bg-gray-600 text-gray-300' : 'bg-gray-200 text-gray-600'
            }`}
            aria-label="Share"
          >
            <Share2 size={16} />
          </motion.button>
        </div>
      )}
    </div>
  );
};

export default TranslationOutput;