import React from 'react';
import { Moon, Sun, Globe } from 'lucide-react';
import { motion } from 'framer-motion';
import { useTheme } from '../contexts/ThemeContext';

const Navbar: React.FC = () => {
  const { theme, toggleTheme } = useTheme();
  
  return (
    <nav className={`sticky top-0 z-10 transition-colors duration-300 ${
      theme === 'dark' 
        ? 'bg-gray-900/95 text-white border-b border-gray-800' 
        : 'bg-white/95 text-gray-900 border-b border-gray-200'
    } backdrop-blur-sm`}>
      <div className="container mx-auto px-4 py-4 flex items-center justify-between">
        <motion.div 
          className="flex items-center space-x-2"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.5 }}
        >
          <Globe className="w-7 h-7 text-primary-600" />
          <span className="text-xl font-bold">Lingua</span>
        </motion.div>
        
        <div className="flex items-center space-x-4">
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={toggleTheme}
            className={`p-2 rounded-full ${
              theme === 'dark' ? 'bg-gray-800 text-yellow-400' : 'bg-gray-100 text-gray-700'
            }`}
            aria-label="Toggle theme"
          >
            {theme === 'dark' ? <Sun size={20} /> : <Moon size={20} />}
          </motion.button>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;