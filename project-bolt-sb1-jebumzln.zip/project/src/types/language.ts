export interface Language {
  name: string;
  code: string;
  countryCode: string;
}

export interface TranslationRequest {
  text: string;
  sourceLanguage: string;
  targetLanguage: string;
}

export interface TranslationResponse {
  translatedText: string;
  detectedLanguage?: {
    language: string;
    confidence: number;
  };
}