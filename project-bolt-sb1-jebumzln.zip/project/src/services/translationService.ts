import { TranslationRequest, TranslationResponse } from '../types/language';

// In a real app, this would be a call to a translation API
// For demonstration purposes, we'll simulate the translation

// Mock translation logic
const mockTranslations: Record<string, Record<string, string>> = {
  'en': {
    'es': 'Hola, este es un texto traducido al español.',
    'fr': 'Bonjour, voici un texte traduit en français.',
    'de': 'Hallo, das ist ein ins Deutsche übersetzter Text.',
    'zh': '你好，这是翻译成中文的文本。',
    'ja': 'こんにちは、これは日本語に翻訳されたテキストです。',
    'ru': 'Привет, это текст, переведенный на русский язык.',
    'ar': 'مرحبا، هذا نص مترجم إلى اللغة العربية.',
    'hi': 'नमस्ते, यह हिंदी में अनुवादित पाठ है।',
  }
};

// Map of common phrases that we'll use for any language
const commonPhrases: Record<string, Record<string, string>> = {
  'hello': {
    'en': 'Hello',
    'es': 'Hola',
    'fr': 'Bonjour',
    'de': 'Hallo',
    'zh': '你好',
    'ja': 'こんにちは',
    'ru': 'Привет',
    'ar': 'مرحبا',
    'hi': 'नमस्ते',
  },
  'thank you': {
    'en': 'Thank you',
    'es': 'Gracias',
    'fr': 'Merci',
    'de': 'Danke',
    'zh': '谢谢',
    'ja': 'ありがとう',
    'ru': 'Спасибо',
    'ar': 'شكرا',
    'hi': 'धन्यवाद',
  },
  'goodbye': {
    'en': 'Goodbye',
    'es': 'Adiós',
    'fr': 'Au revoir',
    'de': 'Auf Wiedersehen',
    'zh': '再见',
    'ja': 'さようなら',
    'ru': 'До свидания',
    'ar': 'وداعا',
    'hi': 'अलविदा',
  }
};

export const translateText = async (request: TranslationRequest): Promise<string> => {
  const { text, sourceLanguage, targetLanguage } = request;
  
  // For demonstration, add a small delay to simulate API call
  await new Promise(resolve => setTimeout(resolve, 1000));
  
  // Check if we have predefined mock translation
  if (mockTranslations[sourceLanguage]?.[targetLanguage]) {
    return mockTranslations[sourceLanguage][targetLanguage];
  }
  
  // Check for common phrases
  const lowerText = text.toLowerCase().trim();
  for (const [phrase, translations] of Object.entries(commonPhrases)) {
    if (lowerText.includes(phrase)) {
      if (translations[targetLanguage]) {
        return translations[targetLanguage];
      }
    }
  }
  
  // Create a simple mock translation by appending "[Translated to X]" to the original text
  let targetLangName;
  switch (targetLanguage) {
    case 'es': targetLangName = 'Spanish'; break;
    case 'fr': targetLangName = 'French'; break;
    case 'de': targetLangName = 'German'; break;
    case 'zh': targetLangName = 'Chinese'; break;
    case 'ja': targetLangName = 'Japanese'; break;
    case 'ru': targetLangName = 'Russian'; break;
    case 'ar': targetLangName = 'Arabic'; break;
    case 'hi': targetLangName = 'Hindi'; break;
    default: targetLangName = targetLanguage;
  }
  
  return `${text} [Translated to ${targetLangName}]`;
};