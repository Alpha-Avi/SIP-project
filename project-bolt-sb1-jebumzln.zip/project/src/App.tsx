import React from 'react';
import { ThemeProvider } from './contexts/ThemeContext';
import TranslatorApp from './components/TranslatorApp';

function App() {
  return (
    <ThemeProvider>
      <TranslatorApp />
    </ThemeProvider>
  );
}

export default App;